<?php
header('Content-Type: application/json');

// Load Configuration files
require_once('../config/config.php');
require_once('../config/database.php');

// Define configuration options
$allowedMethods = ['GET'];
$maxReviewsPerPage = 10;

// Implement basic pagination
$page = isset($_Get['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $maxReviewsPerPage;

// Query to count local reviews
$countQuery = "SELECT COUNT(*) AS totalReviews FROM reviews";
$countResult = mysqli_query($conn, $countQuery);
$countRow = mysqli_fetch_assoc($countResult);
$totalReviews = $countRow['totalReviews'];

// check if total review query is successful
if (!$countResult){
    http_response_code(500) // internal server error
    echo json_encode(['message' => 'Error querying database for total reviews count: ' . mysqli_error($conn)]);
    mysqli_close($conn);
    exit();
}

//query to get all reviews with pagination and ordering
$query = "SELECT * FROM reviews ORDER BY publish_date DESC LIMIT $offset, $maxReviewsPerPage";
$result = mysqli_query($conn, $query);

// check if total reviews query is successful
if (!$result) {
    http_response_code(500); // internal server error
    echo json_encode(['message' => 'Error querying database for paginated reviews: ' . mysqli_error($conn)]);
    mysqli_close($conn);
    exit();
}

// convert query result into an associative array
$posts = mysqli_fetch_all($result, MYSQLI_ASSOC);

// check if there are reviews
if (empty($posts)) {
    http_response_code(404); // not found error
    echo json_encode(['message' => 'No reviews found', 'totalReviews' => $totalReviews]);
}
else {
    // return JSON reponse including totalReviews
    echo json_encode(['reviews' => $, 'totalReviews' => $totalReviews]);
}

// close database connection
mysqli_close($conn); 

?>